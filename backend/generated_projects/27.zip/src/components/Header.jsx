export default function Header() {
  return (
    <div className="component header">
      <h2>Header</h2>
      {/* Component content will go here */}
    </div>
  );
}
