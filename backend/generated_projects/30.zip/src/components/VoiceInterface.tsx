
type Props = {
  // Add props here
};
export default function VoiceInterface(Props ) {
  return (
    <div className="component voiceinterface">
      <h2>VoiceInterface</h2>
      {/* Component content will go here */}
    </div>
  );
}
