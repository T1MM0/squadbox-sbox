
type Props = {
  // Add props here
};
export default function TrainingDashboard(Props ) {
  return (
    <div className="component trainingdashboard">
      <h2>TrainingDashboard</h2>
      {/* Component content will go here */}
    </div>
  );
}
