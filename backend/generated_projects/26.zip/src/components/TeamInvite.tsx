
type Props = {
  // Add props here
};
export default function TeamInvite(Props ) {
  return (
    <div className="component teaminvite">
      <h2>TeamInvite</h2>
      {/* Component content will go here */}
    </div>
  );
}
