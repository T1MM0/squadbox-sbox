export default function FeatureCard() {
  return (
    <div className="component featurecard">
      <h2>FeatureCard</h2>
      {/* Component content will go here */}
    </div>
  );
}
