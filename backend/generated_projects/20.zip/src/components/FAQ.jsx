export default function FAQ() {
  return (
    <div className="component faq">
      <h2>FAQ</h2>
      {/* Component content will go here */}
    </div>
  );
}
