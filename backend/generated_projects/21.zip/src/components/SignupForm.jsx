export default function SignupForm() {
  return (
    <div className="component signupform">
      <h2>SignupForm</h2>
      {/* Component content will go here */}
    </div>
  );
}
